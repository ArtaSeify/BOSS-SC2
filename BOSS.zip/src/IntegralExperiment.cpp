/* -*- c-basic-offset: 4 -*- */

#include "IntegralExperiment.h"
#include "CombatSearch.h"
#include "CombatSearch_Integral.h"
#include "CombatSearch_Bucket.h"
#include "CombatSearch_BestResponse.h"
#include "CombatSearch_IntegralMCTS.h"
#include "FileTools.h"
#include <thread>

using namespace BOSS;

IntegralExperiment::IntegralExperiment()
    : m_race(Races::None)
{

}

IntegralExperiment::IntegralExperiment(const std::string & experimentName, const json & exp)
    : m_name(experimentName)
    , m_race(Races::None)
{
    BOSS_ASSERT(exp.count("Race") && exp["Race"].is_string(), "IntegralExperiment must have a 'Race' string");
    m_race = Races::GetRaceID(exp["Race"]);

    BOSS_ASSERT(exp.count("OutputDir") && exp["OutputDir"].is_string(), "IntegralExperiment must have an 'OutputDir' string");
    m_outputDir = exp["OutputDir"].get<std::string>();

    BOSS_ASSERT(exp.count("StartingState") && exp["StartingState"].is_string(), "IntegralExperiment must have a 'StartingState' string");
    m_params.setInitialState(BOSSConfig::Instance().GetState(exp["StartingState"]));

    BOSS_ASSERT(exp.count("FrameTimeLimit") && exp["FrameTimeLimit"].is_number_integer(), "IntegralExperiment must have a 'FrameTimeLimit' int");
    m_params.setFrameTimeLimit(exp["FrameTimeLimit"]);

    BOSS_ASSERT(exp.count("SearchTimeLimitMS") && exp["SearchTimeLimitMS"].is_number_integer(), "IntegralExperiment must have a 'SearchTimeLimitMS' int");
    m_params.setSearchTimeLimit(exp["SearchTimeLimitMS"]);

    BOSS_ASSERT(exp.count("PrintNewBest") && exp["PrintNewBest"].is_boolean(), "IntegralExperiment must have a PrintNewBest bool");
    m_params.setPrintNewBest(exp["PrintNewBest"]);

    BOSS_ASSERT(exp.count("SortActions") && exp["SortActions"].is_boolean(), "IntegralSearch must have a SortActions bool");
    m_params.setSortActions(exp["SortActions"]);

    BOSS_ASSERT(exp.count("SaveStates") && exp["SaveStates"].is_boolean(), "IntegralSearch must have a SaveStates bool");
    m_params.setSaveStates(exp["SaveStates"]);

    BOSS_ASSERT(exp.count("UseNetwork") && exp["UseNetwork"].is_boolean(), "IntegralSearch must have a UseNetwork bool");
    m_params.setNetworkPrediction(exp["UseNetwork"]);

    BOSS_ASSERT(exp.count("Threads") && exp["Threads"].is_number_integer(), "Integral Search must have a Threads int");
    m_params.setThreadsForExperiment(exp["Threads"]);

    const std::string & searchType = exp["SearchType"][0].get<std::string>();
    m_searchType = searchType;

    if (searchType == "IntegralMCTS")
    {
        auto & searchParameters = exp["SearchParameters"];
        m_params.setExplorationValue(searchParameters["ExplorationConstant"]);
        m_params.setUseMaxValue(searchParameters["UseMax"]);

        if (searchParameters.count("Simulations"))
        {
            m_params.setNumberOfSimulations(searchParameters["Simulations"]);
        }
        else
        {
            m_params.setNumberOfSimulations(std::numeric_limits<int>::max());
        }

        if (searchParameters.count("Nodes"))
        {
            m_params.setNumberOfNodes(searchParameters["Nodes"]);
        }
        else
        {
            m_params.setNumberOfNodes(std::numeric_limits<int>::max());
        }
       
        std::stringstream ss;
        ss << std::fixed << std::setprecision(2) << m_params.getExplorationValue();
        m_name += "C" + ss.str();
    }

    if (searchType == "IntegralDFS")
    {
        m_name += "DFS";
    }

    if (exp.count("MaxActions"))
    {
        const json & maxActions = exp["MaxActions"];
        BOSS_ASSERT(maxActions.is_array(), "MaxActions is not an array");

        for (size_t i(0); i < maxActions.size(); ++i)
        {
            BOSS_ASSERT(maxActions[i].is_array(), "MaxActions element must be array of size 2");

            BOSS_ASSERT(maxActions[i].size() == 2 && maxActions[i][0u].is_string() && maxActions[i][1u].is_number_integer(), "MaxActions element must be [\"Action\", Count]");

            const std::string & typeName = maxActions[i][0u];

            BOSS_ASSERT(ActionTypes::TypeExists(typeName), "Action Type doesn't exist: %s", typeName.c_str());

            m_params.setMaxActions(ActionTypes::GetActionType(typeName), maxActions[i][1]);
        }
    }

    if (exp.count("RelevantActions"))
    {
        const json & relevantActions = exp["RelevantActions"];
        BOSS_ASSERT(relevantActions.is_array(), "RelevantActions is not an array");

        ActionSetAbilities relevantActionSet;

        for (size_t i(0); i < relevantActions.size(); ++i)
        {
            BOSS_ASSERT(relevantActions[i].is_string(), "RelvantActions element must be action type string");
            std::string element = relevantActions[i];
            BOSS_ASSERT(ActionTypes::TypeExists(relevantActions[i]), "Action Type doesn't exist: %s", element.c_str());

            relevantActionSet.add(ActionTypes::GetActionType(element));
        }

        m_params.setRelevantActions(relevantActionSet);
    }

    if (exp.count("AlwaysMakeWorkers"))
    {
        BOSS_ASSERT(exp["AlwaysMakeWorkers"].is_boolean(), "AlwaysMakeWorkers should be a bool");

        m_params.setAlwaysMakeWorkers(exp["AlwaysMakeWorkers"]);
    }

    if (exp.count("OpeningBuildOrder"))
    {
        BOSS_ASSERT(exp["OpeningBuildOrder"].is_string(), "OpeningBuildOrder should be a string");
        m_params.setOpeningBuildOrder(BOSSConfig::Instance().GetBuildOrder(exp["OpeningBuildOrder"]));
    }

    if (exp.count("BestResponseParams"))
    {
        const json & brVal = exp["BestResponseParams"];

        BOSS_ASSERT(brVal.is_object(), "BestResponseParams not an object");
        BOSS_ASSERT(brVal.count("EnemyState"), "bestResponseParams must have 'enemyState' string");
        BOSS_ASSERT(brVal.count("EnemyBuildOrder"), "bestResponseParams must have 'enemyBuildOrder' string");

        BOSS_ASSERT(brVal.count("EnemyState") && brVal["EnemyState"].is_string(), "bestResponseParams must have a 'EnemyState' string");
        m_params.setEnemyInitialState(BOSSConfig::Instance().GetState(brVal["EnemyState"]));

        BOSS_ASSERT(brVal.count("EnemyBuildOrder") && brVal["EnemyBuildOrder"].is_string(), "BestResponseParams must have a 'EnemyBuildOrder' string");
        m_params.setEnemyBuildOrder(BOSSConfig::Instance().GetBuildOrder(brVal["EnemyBuildOrder"]));
    }

    if (exp.count("SimulationsPerStep"))
    {
        BOSS_ASSERT(exp["SimulationsPerStep"].is_array() && exp["SimulationsPerStep"].size() == 2, "SimulationsPerStep must be an array of size 2");
        m_params.setChangingRoot(exp["SimulationsPerStep"][0]);
        m_params.setSimulationsPerStep(exp["SimulationsPerStep"][1]);
    }
}

void IntegralExperiment::runExperimentThread(int thread, int runForThread)
{
    static std::string stars = "************************************************";

    for (int i(0); i < runForThread; ++i)
    {
        int index = i + (thread * runForThread);

        std::string name = m_name + "Run" + std::to_string(index);
        std::string outputDir = m_outputDir + "/" + Assert::CurrentDateTime() + "_" + name;
        FileTools::MakeDirectory(outputDir);

        std::string resultsFile = name;

        std::cout << "\n" << stars << "\n* Running Experiment: " << name << " [" << m_searchType << "]\n" << stars << "\n";

        std::unique_ptr<CombatSearch> combatSearch;

        if (m_searchType == "IntegralDFS")
        {
            combatSearch = std::unique_ptr<CombatSearch>(new CombatSearch_Integral(m_params, index, outputDir, resultsFile, m_name));
            //resultsFile += "_Integral";
        }
        else if (m_searchType == "IntegralMCTS")
        {
            //resultsFile += "_IntegralMCTS";
            combatSearch = std::unique_ptr<CombatSearch>(new CombatSearch_IntegralMCTS(m_params, outputDir, resultsFile, m_name));
        }
        else
        {
            BOSS_ASSERT(false, "CombatSearch type not found: %s", m_searchType.c_str());
        }

        combatSearch->search();
        combatSearch->printResults();
        combatSearch->writeResultsFile(outputDir, resultsFile);
        const CombatSearchResults & results = combatSearch->getResults();
    }
}

void IntegralExperiment::run(int numberOfRuns)
{
    FileTools::MakeDirectory(m_outputDir);

    if (m_params.getSaveStates())
    {
        FileTools::MakeDirectory(CONSTANTS::ExecutablePath + "/data/DataTuples");
        FileTools::MakeDirectory(CONSTANTS::ExecutablePath + "/data/DataTuples/SearchData");
    }

    
    int runPerThread = 0;
    int numThreads = m_params.getThreadsForExperiment();

    while (runPerThread == 0)
    {
       runPerThread = int(numberOfRuns / numThreads);
       if (runPerThread == 0)
       {
           numThreads--;
       }
    }
    std::vector<std::thread> threads(numThreads);

    for (int thread = 0; thread < numThreads; ++thread)
    {
        threads[thread] = std::thread(&IntegralExperiment::runExperimentThread, this, thread, runPerThread);
        std::this_thread::sleep_for(std::chrono::milliseconds(250));
    }

    for (auto & thread : threads)
    {
        thread.join();
    }
}
