/* -*- c-basic-offset: 4 -*- */

#include "Constants.h"

namespace BOSS
{
	/*constants::constants()
	{

	}

	constants & constants::Instance()
	{
		static constants constants;
		return constants;
	}

	void constants::SetMPWPF(const double & new_MPWPF) 
	{
		MPWPF = new_MPWPF;
	}

	void constants::SetGPWPF(const double & new_GPWPF) 
	{
		GPWPF = new_GPWPF;
	}

	void constants::SetERPF(const double & new_ERPF)
	{
		ERPF = new_ERPF;
	}

	void constants::SetHRPF(const double & new_HRPF)
	{
		HRPF = new_HRPF;
	}

	void constants::SetSRPF(const double & new_SRPF)
	{
		SRPF = new_SRPF;
	}

	void constants::SetWorkersPerRefinery(const int & new_WPR)
	{
		WorkersPerRefinery = new_WPR;
	}


	const double constants::GetMPWPF() const 
	{
		return MPWPF;
	}

	const double constants::GetGPWPF() const
	{
		return GPWPF;
	}

	const double constants::GetERPF() const
	{
		return ERPF;
	}

	const double constants::GetHRPF() const
	{
		return HRPF;
	}

	const double constants::GetSRPF() const
	{
		return SRPF;
	}

	const double constants::GetWorkersPerRefinery() const
	{
		return WorkersPerRefinery;
	}*/
}
