/* -*- c-basic-offset: 4 -*- */

#pragma once

#include "Common.h"

namespace BOSS
{

/*class constants {
  double MPWPF;				// minerals per worker per frame
  double GPWPF;				// gas per worker per frame
  double ERPF;				// energy regen per frame
  double HRPF;				// health regen per frame
  double SRPF;				// shield regen per frame
  int WorkersPerRefinery;

  public:
  constants();
  static constants & Instance();

  void SetMPWPF(const double & new_MPWPF);
  void SetGPWPF(const double & new_GPWPF);
  void SetERPF(const double & new_ERPF);
  void SetHRPF(const double & new_HRPF);
  void SetSRPF(const double & new_SRPF);
  void SetWorkersPerRefinery(const int & new_WPR);

  const double GetMPWPF() const;
  const double GetGPWPF() const;
  const double GetERPF() const;
  const double GetHRPF() const;
  const double GetSRPF() const;
  const double GetWorkersPerRefinery() const;
  };*/
}
