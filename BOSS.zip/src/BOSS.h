/* -*- c-basic-offset: 4 -*- */

#pragma once

#include "Common.h"
#include "BOSSConfig.h"
#include "GameState.h"

namespace BOSS
{
    void Init(const std::string & filename);
    void InitializeConstants(const json & j);
}
