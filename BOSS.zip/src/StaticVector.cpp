/* -*- c-basic-offset: 4 -*- */

#include "StaticVector.h"
