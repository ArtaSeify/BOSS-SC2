/* -*- c-basic-offset: 4 -*- */

#pragma once

#include "BOSS.h"
#include "JSONTools.h"
#include "CombatSearchParameters.h"
#include "BuildOrderAbilities.h"

namespace BOSS
{

    class CombatSearchExperiment
    {
        std::string                 m_name;
        std::string                 m_outputDir;
        CombatSearchParameters      m_params;
        RaceID                      m_race;
        std::vector<std::string>    m_searchTypes;

        //!!! PROBLEM UNUSED RaceID                      m_enemyRace;
        BuildOrderAbilities         m_enemyBuildOrder;

    public:

        CombatSearchExperiment();
        CombatSearchExperiment(const std::string & name, const json & experimentVal);

        void run();
    };
}
